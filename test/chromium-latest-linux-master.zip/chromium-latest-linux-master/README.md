# chromium-latest-linux
Scripts to download and run the latest Linux build of Chromium.
