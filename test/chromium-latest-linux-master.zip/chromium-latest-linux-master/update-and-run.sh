#! /bin/bash
cd $(dirname $0)
./update.sh && ./run.sh
